#!/bin/bash

./waf configure
./waf build run --app=main
