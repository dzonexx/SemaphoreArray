
#ifndef glob_hpp
#define glob_hpp

#include <string>
#include <vector>

using namespace std;

vector<string> glob(const string& pattern);


#endif /* glob_hpp */
